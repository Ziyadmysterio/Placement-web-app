-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2020 at 12:21 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `placement_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`) VALUES
(1, 'admin', 'admin', '$2y$10$7aFBUYg/qKOPcVf5le6ZMeBqhoOZ6YlAsW/rZhkpRx2MO5vEsAs2u');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `c_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `link` varchar(200) NOT NULL,
  `p_no` int(40) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `logo_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`c_id`, `name`, `email`, `address`, `description`, `link`, `p_no`, `logo`, `logo_name`) VALUES
(15, ' Microsoft', 'hr@microsoft.com', 'Headquarters: Hyderabad, India', 'Microsoft India Private Limited is a subsidiary of American software company Microsoft Corporation, headquartered in Hyderabad, India. The company first entered the Indian market in 1990 and has since worked closely with the Indian government, the IT industry, academia and the local developer community to usher in some of the early successes in the IT market. Microsoft currently has offices in the 9 cities of Ahmedabad, Bangalore, Chennai, Hyderabad, Kochi, Kolkata, Mumbai, the NCR (New Delhi an', 'microsoft.com', 64614641, '../public/assets/logo/microsoft.jpg', 'microsoft.jpg'),
(16, '   IBM', 'hr@ibm.com', 'Headquarters	Bangalore, Karnataka, India', 'India Private Limited is the Indian subsidiary of IBM.[3] It has facilities in Ahmedabad, Bengaluru, Bhubaneshwar, Chennai, Coimbatore, Delhi, Gurgaon, Hyderabad, Kolkata, Mumbai, Noida, Pune, Thiruvananthapuram and Visakhapatnam.\r\n\r\nBetween 2003 and 2007, IBM\'s head count in India has grown by almost 800%, from 9,000 in 2003[4] to nearly 74,000 in 2007.[5] Since 2006, IBM has been the multinational with the largest number of employees in India.[6] IBM is very secretive about the geographic distribution of its employees. By most estimates, it has close to a third of its 430,000 employees (~ 140,000) in India, and it likely has more employees there than in the US.[7] ', 'ibm.com', 8168464, '../public/assets/logo/ibm.jpg', 'ibm.jpg'),
(17, ' Tata Consultancy Service', 'hr@tcs.com', 'Headquarters	Mangalore, Karnataka, India', 'Tata Consultancy Services Limited (TCS) is an Indian multinational information technology (IT) services and consulting company headquartered in Mumbai, Maharashtra, India.[6][7] It is a subsidiary of the Tata Group and operates in 149 locations across 46 countries.[8]\r\n\r\nTCS is the second largest Indian company by market capitalisation.[9][10] Tata consultancy services is now placed among the most valuable IT services brands worldwide.[11] In 2015, TCS was ranked 64th overall in the Forbes World\'s Most Innovative Companies ranking, making it both the highest-ranked IT services company and the top Indian company.', 'tcs.com', 74681689, '../public/assets/logo/tcs.jpg', 'tcs.jpg'),
(18, ' Dxc', 'hr@dxc.com', 'Headquarters	Bangalore, Karnataka, India                                    ', 'DXC Technology in India is a hotbed of innovation and technical expertise and a gold standard for process maturity and quality. Our operations are the company’s largest globally, employing high-caliber technology professionals focused on helping customers address their core challenges and take advantage of market opportunities.', 'dxc.com', 6864, '../public/assets/logo/dxc.jpg', 'dxc.jpg'),
(20, '  Apple', 'hr@apple.com', 'Headquarters	Bangalore, Karnataka, India', 'Apple Inc. is an American multinational technology company headquartered in Cupertino, California, that designs, develops and sells consumer electronics, computer software, and online services. It is considered one of the Big Five companies in the U.S. information technology industry, along with Amazon, Google, Microsoft, and Facebook.[8][9][10]\r\n\r\nThe company\'s hardware products include the iPhone smartphone, the iPad tablet computer, the Mac personal computer, the iPod portable media player, t', 'apple.com', 5000, '../public/assets/logo/apple.jpg', 'apple.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `p_id` int(20) NOT NULL,
  `c_id` int(20) NOT NULL,
  `position` varchar(200) NOT NULL,
  `about` varchar(500) NOT NULL,
  `requirement` varchar(500) NOT NULL,
  `salary` int(30) NOT NULL,
  `d_date` date NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`p_id`, `c_id`, `position`, `about`, `requirement`, `salary`, `d_date`, `uploaded_at`) VALUES
(9, 15, 'Web Developer', 'Design Front end and professonal websites', 'Good Knowledge in PHP,CSS,HTML', 500, '2020-12-25', '2020-12-24 13:49:32'),
(13, 20, 'IOS Developer', 'Design IOS apps using desired frameworks.\r\n', 'Swift Knowledge is Mandatory', 5000, '2020-12-09', '2020-12-26 12:07:00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `college_name` varchar(200) NOT NULL,
  `yog` year(4) NOT NULL,
  `gpa` float NOT NULL,
  `cv` varchar(200) NOT NULL,
  `profile_photo` varchar(200) NOT NULL,
  `cv_path` varchar(200) NOT NULL,
  `profile_path` varchar(200) NOT NULL,
  `cv_temp` varchar(200) NOT NULL,
  `profile_temp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `name`, `username`, `email`, `password`, `dob`, `gender`, `course_name`, `college_name`, `yog`, `gpa`, `cv`, `profile_photo`, `cv_path`, `profile_path`, `cv_temp`, `profile_temp`) VALUES
(1, 'Mohammed shaikathul Ziyad', 'ziyad7', 'afziyad@gmail.com', '$2y$10$Zn7WCTaLWyivyGxS9OlgU.BgzrMZ5w1/1fzaOLzRFOWiLVmwqpLw.', '2020-12-10', 'male', 'computer Science', 'mite', 2020, 9, 'Offer Letter - Mohammed Shaikathul Ziyad(1).pdf', 'IMG_8599.jpg', '../public/assets/cv/Offer Letter - Mohammed Shaikathul Ziyad(1).pdf', '../public/assets/profile/IMG_8599.jpg', 'E:Appsxamp	mpphpE011.tmp', 'E:Appsxamp	mpphpE051.tmp'),
(52, 'Fathima Suha', 'suha', 'fathimasuha@gmail.com', '$2y$10$IPGRHpyF8OPUHUk4WNer7eZEk5GjfJUcP46vpgewHFOpQdRB75CjC', '2020-12-16', 'female', 'computer Science', 'Joseph', 2020, 8, 'July-2019.pdf', 'student2.jpg', '../public/assets/cv/July-2019.pdf', '../public/assets/profile/student2.jpg', 'E:Appsxamp	mpphpFC29.tmp', 'E:Appsxamp	mpphpFC3A.tmp');

-- --------------------------------------------------------

--
-- Table structure for table `student_applied`
--

CREATE TABLE `student_applied` (
  `sa_id` int(20) NOT NULL,
  `s_id` int(20) NOT NULL,
  `pl_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_training`
--

CREATE TABLE `student_training` (
  `st_id` int(20) NOT NULL,
  `s_id` int(20) NOT NULL,
  `t_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `training`
--

CREATE TABLE `training` (
  `t_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `training_at` date NOT NULL,
  `trained_by` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `training`
--

INSERT INTO `training` (`t_id`, `name`, `training_at`, `trained_by`, `status`) VALUES
(3, 'java', '2020-12-18', 'Ziyad', 'on going'),
(8, 'Mohammed', '2020-12-24', 'ziyad', 'on going');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `cmp_id_fk` (`c_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `student_applied`
--
ALTER TABLE `student_applied`
  ADD PRIMARY KEY (`sa_id`),
  ADD KEY `s_id_fk` (`s_id`),
  ADD KEY `pl_id_fk` (`pl_id`);

--
-- Indexes for table `student_training`
--
ALTER TABLE `student_training`
  ADD PRIMARY KEY (`st_id`),
  ADD KEY `st_id_fk` (`s_id`),
  ADD KEY `t_id_fk` (`t_id`);

--
-- Indexes for table `training`
--
ALTER TABLE `training`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `c_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `placement`
--
ALTER TABLE `placement`
  MODIFY `p_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `s_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `student_applied`
--
ALTER TABLE `student_applied`
  MODIFY `sa_id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_training`
--
ALTER TABLE `student_training`
  MODIFY `st_id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `training`
--
ALTER TABLE `training`
  MODIFY `t_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `placement`
--
ALTER TABLE `placement`
  ADD CONSTRAINT `cmp_id_fk` FOREIGN KEY (`c_id`) REFERENCES `company` (`c_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `student_applied`
--
ALTER TABLE `student_applied`
  ADD CONSTRAINT `pl_id_fk` FOREIGN KEY (`pl_id`) REFERENCES `placement` (`p_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `s_id_fk` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `student_training`
--
ALTER TABLE `student_training`
  ADD CONSTRAINT `st_id_fk` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `t_id_fk` FOREIGN KEY (`t_id`) REFERENCES `training` (`t_id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
